#!/bin/bash
cd server/files
java -Xmx768M -jar server.jar 
