#!/bin/bash
cd server
java -Xmx512M -jar server.jar 
